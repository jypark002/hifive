package hifive;

import javax.persistence.*;
import org.springframework.beans.BeanUtils;
import java.util.List;
import java.util.Date;

@Entity
@Table(name="Pay_table")
public class Pay {

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long payId;
    private String status;
    private Long conferenceId;
    private Long roomNumber;

    @PostPersist
    public void onPostPersist() {
        System.out.println("********************* Pay Paid Start.");
        Paid paid = new Paid();
        paid.setPayId(this.getPayId());
        paid.setPayStatus(this.getStatus());
        paid.setConferenceId(this.getConferenceId());
        paid.setRoomNumber(this.getRoomNumber());
        BeanUtils.copyProperties(this, paid);
        paid.publishAfterCommit();

        System.out.println("********************* Pay Paid End.");
    }

    @PrePersist
    public void onPrePersist() {
        System.out.println("********************* Pay PayCanceled Start.");
        PayCanceled payCanceled = new PayCanceled();
        payCanceled.setPayId(this.getPayId());
        payCanceled.setPayStatus(this.getStatus());
        payCanceled.setConferenceId(this.getConferenceId());
        BeanUtils.copyProperties(this, payCanceled);
        payCanceled.publishAfterCommit();

        System.out.println("********************* Pay PayCanceled End.");
    }


    public Long getPayId() {
        return payId;
    }
    public void setPayId(Long payId) {
        this.payId = payId;
    }

    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }

    public Long getConferenceId() {
        return conferenceId;
    }
    public void setConferenceId(Long conferenceId) {
        this.conferenceId = conferenceId;
    }

    public Long getRoomNumber() { return roomNumber; }
    public void setRoomNumber(Long roomNumber) { this.roomNumber = roomNumber; }
}
