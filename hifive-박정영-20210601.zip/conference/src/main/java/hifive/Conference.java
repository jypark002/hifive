package hifive;

import javax.persistence.*;
import org.springframework.beans.BeanUtils;
import java.util.List;
import java.util.Date;

@Entity
@Table(name="Conference_table")
public class Conference {

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long conferenceId;
    private String status;
    private Long payId;
    private Long roomNumber;

    @PostPersist
    public void onPostPersist() {
        System.out.println("********************* Conference Apply Start.");
        setStatus("CREATED");   // 회의 상태 : CREATED | PAID | ASSIGNED | CANCELED

        Applied applied = new Applied();
        applied.setConferenceId(this.getConferenceId());
        applied.setConferenceStatus(this.getStatus());
        applied.setRoomNumber(this.getRoomNumber());
        BeanUtils.copyProperties(this, applied);
        applied.publishAfterCommit();

        // 결재 확인 Req/Res
        hifive.external.Pay pay = new hifive.external.Pay();
        pay.setConferenceId(this.getConferenceId());
        pay.setStatus("PAID");

        // mappings goes here
        ConferenceApplication.applicationContext.getBean(hifive.external.PayService.class)
                .pay(pay);

        System.out.println("********************* Conference Apply End.");
    }

    @PreRemove
    public void onPreRemove() {
        ApplyCanceled applyCanceled = new ApplyCanceled();
        applyCanceled.setConferenceId(this.getConferenceId());
        applyCanceled.setConferenceStatus(this.getStatus());
        applyCanceled.setPayId(this.getPayId());
        BeanUtils.copyProperties(this, applyCanceled);
        applyCanceled.publishAfterCommit();
    }

    public Long getConferenceId() {
        return conferenceId;
    }
    public void setConferenceId(Long conferenceId) {
        this.conferenceId = conferenceId;
    }

    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }

    public Long getPayId() {
        return payId;
    }
    public void setPayId(Long payId) {
        this.payId = payId;
    }

    public Long getRoomNumber() {
        return roomNumber;
    }
    public void setRoomNumber(Long roomNumber) {
        this.roomNumber = roomNumber;
    }

}
